CREATE TABLE Employees(
  employee_name varchar(50) NOT NULL,
  Department char (50) NOT NULL,
  PhoneNo int NOT NULL,
  Address char (100) NOT NULL,
  zip-code int;
  )

insert into Employees (employee_name,Department,PhoneNo,Address,zip-code) values('Sumit kumar','CSE',5342783778,'sfdsfddf',67338),('Karanjit','IT',5647588284,'dfgdfgrfdsf',453777),('Paramjit','ECE',4653745787,'sfsgrhthtrh',587854);
select *FROM Employees;
